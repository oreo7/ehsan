#!/bin/bash 
 COUNTER=0
while [ $COUNTER -lt 1 ]; do
bash launch.sh
sleep 1
#let COUNTER=COUNTER+1 
done
